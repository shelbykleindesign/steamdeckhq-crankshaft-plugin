# SDHQ Rating Indicator for Crankshaft Plugin Manager on Steam Deck

View the SDHQ Rating right on your favorite game's page!
