import { h } from 'dom-chef';
export { h };